# People Before Power – Projekttext

People Before Power befindet sich in einer geschlossenen Testphase vor dem öffentlichen Launch. Ziel dieser Phase ist es, die Kernbotschaft, die visuelle Sprache, die Zielgruppenansprache und die Wahrnehmung möglicher Risiken systematisch zu prüfen und zu verbessern.

Der Testlauf ist bewusst als strukturierter Prozess angelegt. Er beginnt mit einem kontrollierten inneren Kreis aus vertrauenswürdigen Personen und kleinen Gruppen, geht anschließend in einen Pilotbereich mit DJs, Artists und Musikszene-Kontakten über und wird erst danach auf eine breitere Öffentlichkeit und ausgewählte Influencer ausgeweitet.

Im Mittelpunkt steht die Frage, ob People Before Power verständlich, anschlussfähig und mobilisierend genug kommuniziert wird. Geprüft wird insbesondere, ob die Botschaft „99 % vs. 1 %“, der Schwerpunkt auf Blockaden und kollektiver Handlungsfähigkeit sowie die Sprache der Bewegung nicht nur emotional, sondern auch inhaltlich klar ankommen.

Ein weiterer Schwerpunkt ist die Risikoprüfung. Dazu gehören mögliche Missverständnisse im Hinblick auf Legalität, Gewaltwahrnehmung, Verschwörungsassoziationen und die allgemeine politische Einordnung der Bewegung. Diese Punkte sollen früh sichtbar werden, damit die Formulierung, Tonalität und Darstellung vor dem öffentlichen Start angepasst werden können.

Die Testphase läuft über sechs bis acht Wochen und ist in drei Phasen gegliedert. In der ersten Phase wird das Material mit einem kleinen inneren Kreis getestet. Dazu gehören Manifest, Landingpage, One-Pager und visuelle Entwürfe. In der zweiten Phase wird mit DJs, Rap-Artists und anderen Musikakteuren gearbeitet, um kurze Spoken-Word-Formate, Playlists, Flyer und audiovisuelle Einbindungen zu testen. In der dritten Phase werden ausgewählte Influencer einbezogen, um Reichweite, Resonanz und Qualität des Engagements zu messen.

Die wichtigsten Assets der Testphase sind das Manifest, die Landingpage, ein kurzes „About“-Dokument, ein DJ-/Artist-Briefing, ein 30–60 Sekunden Spoken-Word-Text sowie erste Logo- und Mockup-Varianten. Alle Materialien werden versioniert dokumentiert, damit Änderungen nachvollziehbar bleiben.

Erfolg wird nicht nur über Reichweite gemessen, sondern über tatsächliche Anschlussfähigkeit: Wer versteht die Botschaft? Wer reagiert positiv? Wer möchte Inhalte teilen, verlinken, spielen oder weiterentwickeln? Welche Gruppen zeigen Bereitschaft, wiederholt mitzuwirken?

Am Ende der Testphase wird auf Basis der Rückmeldungen entschieden, welche Formulierungen, visuellen Elemente und Formate beibehalten, überarbeitet oder verworfen werden. Das Ziel ist nicht bloß Aufmerksamkeit, sondern eine belastbare Grundlage für den öffentlichen Start einer klaren, konsistenten und anschlussfähigen Bewegung.

## Nächste Schritte
- Landingpage finalisieren.
- Early-Circle-Test starten.
- DJ-/Artist-Kit versenden.
- Feedback auswerten.
- Sprache und Visuals anpassen.
- Launch-Entscheidung treffen.